(function(){"use strict";function mt(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}var ee={exports:{}},pt=ee.exports,Ie;function gt(){return Ie||(Ie=1,(function(e,t){(function(n,o){o(e)})(typeof globalThis<"u"?globalThis:typeof self<"u"?self:pt,function(n){if(!(globalThis.chrome&&globalThis.chrome.runtime&&globalThis.chrome.runtime.id))throw new Error("This script should only be loaded in a browser extension.");if(globalThis.browser&&globalThis.browser.runtime&&globalThis.browser.runtime.id)n.exports=globalThis.browser;else{const o="The message port closed before a response was received.",s=r=>{const a={alarms:{clear:{minArgs:0,maxArgs:1},clearAll:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getAll:{minArgs:0,maxArgs:0}},bookmarks:{create:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},getChildren:{minArgs:1,maxArgs:1},getRecent:{minArgs:1,maxArgs:1},getSubTree:{minArgs:1,maxArgs:1},getTree:{minArgs:0,maxArgs:0},move:{minArgs:2,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeTree:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}},browserAction:{disable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},enable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},getBadgeBackgroundColor:{minArgs:1,maxArgs:1},getBadgeText:{minArgs:1,maxArgs:1},getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},openPopup:{minArgs:0,maxArgs:0},setBadgeBackgroundColor:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setBadgeText:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},browsingData:{remove:{minArgs:2,maxArgs:2},removeCache:{minArgs:1,maxArgs:1},removeCookies:{minArgs:1,maxArgs:1},removeDownloads:{minArgs:1,maxArgs:1},removeFormData:{minArgs:1,maxArgs:1},removeHistory:{minArgs:1,maxArgs:1},removeLocalStorage:{minArgs:1,maxArgs:1},removePasswords:{minArgs:1,maxArgs:1},removePluginData:{minArgs:1,maxArgs:1},settings:{minArgs:0,maxArgs:0}},commands:{getAll:{minArgs:0,maxArgs:0}},contextMenus:{remove:{minArgs:1,maxArgs:1},removeAll:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},cookies:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:1,maxArgs:1},getAllCookieStores:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},devtools:{inspectedWindow:{eval:{minArgs:1,maxArgs:2,singleCallbackArg:!1}},panels:{create:{minArgs:3,maxArgs:3,singleCallbackArg:!0},elements:{createSidebarPane:{minArgs:1,maxArgs:1}}}},downloads:{cancel:{minArgs:1,maxArgs:1},download:{minArgs:1,maxArgs:1},erase:{minArgs:1,maxArgs:1},getFileIcon:{minArgs:1,maxArgs:2},open:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},pause:{minArgs:1,maxArgs:1},removeFile:{minArgs:1,maxArgs:1},resume:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},extension:{isAllowedFileSchemeAccess:{minArgs:0,maxArgs:0},isAllowedIncognitoAccess:{minArgs:0,maxArgs:0}},history:{addUrl:{minArgs:1,maxArgs:1},deleteAll:{minArgs:0,maxArgs:0},deleteRange:{minArgs:1,maxArgs:1},deleteUrl:{minArgs:1,maxArgs:1},getVisits:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1}},i18n:{detectLanguage:{minArgs:1,maxArgs:1},getAcceptLanguages:{minArgs:0,maxArgs:0}},identity:{launchWebAuthFlow:{minArgs:1,maxArgs:1}},idle:{queryState:{minArgs:1,maxArgs:1}},management:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},getSelf:{minArgs:0,maxArgs:0},setEnabled:{minArgs:2,maxArgs:2},uninstallSelf:{minArgs:0,maxArgs:1}},notifications:{clear:{minArgs:1,maxArgs:1},create:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:0},getPermissionLevel:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},pageAction:{getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},hide:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},permissions:{contains:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},request:{minArgs:1,maxArgs:1}},runtime:{getBackgroundPage:{minArgs:0,maxArgs:0},getPlatformInfo:{minArgs:0,maxArgs:0},openOptionsPage:{minArgs:0,maxArgs:0},requestUpdateCheck:{minArgs:0,maxArgs:0},sendMessage:{minArgs:1,maxArgs:3},sendNativeMessage:{minArgs:2,maxArgs:2},setUninstallURL:{minArgs:1,maxArgs:1}},sessions:{getDevices:{minArgs:0,maxArgs:1},getRecentlyClosed:{minArgs:0,maxArgs:1},restore:{minArgs:0,maxArgs:1}},storage:{local:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},managed:{get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1}},sync:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}}},tabs:{captureVisibleTab:{minArgs:0,maxArgs:2},create:{minArgs:1,maxArgs:1},detectLanguage:{minArgs:0,maxArgs:1},discard:{minArgs:0,maxArgs:1},duplicate:{minArgs:1,maxArgs:1},executeScript:{minArgs:1,maxArgs:2},get:{minArgs:1,maxArgs:1},getCurrent:{minArgs:0,maxArgs:0},getZoom:{minArgs:0,maxArgs:1},getZoomSettings:{minArgs:0,maxArgs:1},goBack:{minArgs:0,maxArgs:1},goForward:{minArgs:0,maxArgs:1},highlight:{minArgs:1,maxArgs:1},insertCSS:{minArgs:1,maxArgs:2},move:{minArgs:2,maxArgs:2},query:{minArgs:1,maxArgs:1},reload:{minArgs:0,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeCSS:{minArgs:1,maxArgs:2},sendMessage:{minArgs:2,maxArgs:3},setZoom:{minArgs:1,maxArgs:2},setZoomSettings:{minArgs:1,maxArgs:2},update:{minArgs:1,maxArgs:2}},topSites:{get:{minArgs:0,maxArgs:0}},webNavigation:{getAllFrames:{minArgs:1,maxArgs:1},getFrame:{minArgs:1,maxArgs:1}},webRequest:{handlerBehaviorChanged:{minArgs:0,maxArgs:0}},windows:{create:{minArgs:0,maxArgs:1},get:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:1},getCurrent:{minArgs:0,maxArgs:1},getLastFocused:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}}};if(Object.keys(a).length===0)throw new Error("api-metadata.json has not been included in browser-polyfill");class l extends WeakMap{constructor(p,A=void 0){super(A),this.createItem=p}get(p){return this.has(p)||this.set(p,this.createItem(p)),super.get(p)}}const c=d=>d&&typeof d=="object"&&typeof d.then=="function",m=(d,p)=>(...A)=>{r.runtime.lastError?d.reject(new Error(r.runtime.lastError.message)):p.singleCallbackArg||A.length<=1&&p.singleCallbackArg!==!1?d.resolve(A[0]):d.resolve(A)},i=d=>d==1?"argument":"arguments",u=(d,p)=>function(v,...S){if(S.length<p.minArgs)throw new Error(`Expected at least ${p.minArgs} ${i(p.minArgs)} for ${d}(), got ${S.length}`);if(S.length>p.maxArgs)throw new Error(`Expected at most ${p.maxArgs} ${i(p.maxArgs)} for ${d}(), got ${S.length}`);return new Promise((L,I)=>{if(p.fallbackToNoCallback)try{v[d](...S,m({resolve:L,reject:I},p))}catch(x){console.warn(`${d} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `,x),v[d](...S),p.fallbackToNoCallback=!1,p.noCallback=!0,L()}else p.noCallback?(v[d](...S),L()):v[d](...S,m({resolve:L,reject:I},p))})},b=(d,p,A)=>new Proxy(p,{apply(v,S,L){return A.call(S,d,...L)}});let w=Function.call.bind(Object.prototype.hasOwnProperty);const g=(d,p={},A={})=>{let v=Object.create(null),S={has(I,x){return x in d||x in v},get(I,x,P){if(x in v)return v[x];if(!(x in d))return;let T=d[x];if(typeof T=="function")if(typeof p[x]=="function")T=b(d,d[x],p[x]);else if(w(A,x)){let W=u(x,A[x]);T=b(d,d[x],W)}else T=T.bind(d);else if(typeof T=="object"&&T!==null&&(w(p,x)||w(A,x)))T=g(T,p[x],A[x]);else if(w(A,"*"))T=g(T,p[x],A["*"]);else return Object.defineProperty(v,x,{configurable:!0,enumerable:!0,get(){return d[x]},set(W){d[x]=W}}),T;return v[x]=T,T},set(I,x,P,T){return x in v?v[x]=P:d[x]=P,!0},defineProperty(I,x,P){return Reflect.defineProperty(v,x,P)},deleteProperty(I,x){return Reflect.deleteProperty(v,x)}},L=Object.create(d);return new Proxy(L,S)},h=d=>({addListener(p,A,...v){p.addListener(d.get(A),...v)},hasListener(p,A){return p.hasListener(d.get(A))},removeListener(p,A){p.removeListener(d.get(A))}}),E=new l(d=>typeof d!="function"?d:function(A){const v=g(A,{},{getContent:{minArgs:0,maxArgs:0}});d(v)}),k=new l(d=>typeof d!="function"?d:function(A,v,S){let L=!1,I,x=new Promise(Q=>{I=function(R){L=!0,Q(R)}}),P;try{P=d(A,v,I)}catch(Q){P=Promise.reject(Q)}const T=P!==!0&&c(P);if(P!==!0&&!T&&!L)return!1;const W=Q=>{Q.then(R=>{S(R)},R=>{let _e;R&&(R instanceof Error||typeof R.message=="string")?_e=R.message:_e="An unexpected error occurred",S({__mozWebExtensionPolyfillReject__:!0,message:_e})}).catch(R=>{console.error("Failed to send onMessage rejected reply",R)})};return W(T?P:x),!0}),y=({reject:d,resolve:p},A)=>{r.runtime.lastError?r.runtime.lastError.message===o?p():d(new Error(r.runtime.lastError.message)):A&&A.__mozWebExtensionPolyfillReject__?d(new Error(A.message)):p(A)},f=(d,p,A,...v)=>{if(v.length<p.minArgs)throw new Error(`Expected at least ${p.minArgs} ${i(p.minArgs)} for ${d}(), got ${v.length}`);if(v.length>p.maxArgs)throw new Error(`Expected at most ${p.maxArgs} ${i(p.maxArgs)} for ${d}(), got ${v.length}`);return new Promise((S,L)=>{const I=y.bind(null,{resolve:S,reject:L});v.push(I),A.sendMessage(...v)})},M={devtools:{network:{onRequestFinished:h(E)}},runtime:{onMessage:h(k),onMessageExternal:h(k),sendMessage:f.bind(null,"sendMessage",{minArgs:1,maxArgs:3})},tabs:{sendMessage:f.bind(null,"sendMessage",{minArgs:2,maxArgs:3})}},H={clear:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}};return a.privacy={network:{"*":H},services:{"*":H},websites:{"*":H}},g(r,M,a)};n.exports=s(chrome)}})})(ee)),ee.exports}var ft=gt();const C=mt(ft),ht=/user|email|login|account|phone|mobile|identifier/i,bt=/search|query|coupon|promo|captcha|otp|token|code|zip|postal/i;function de(e){const t=(e.type||"text").toLowerCase();if(t==="password"||t==="hidden"||t==="submit")return!1;const n=(e.autocomplete||"").toLowerCase();if(n.includes("username")||n.includes("email"))return!0;if(n.includes("new-password"))return!1;const o=[e.name,e.id,e.placeholder,e.ariaLabel].filter(Boolean).join(" ");return bt.test(o)?!1:t==="email"?!0:t!=="text"&&t!=="tel"?!1:ht.test(o)}function Pe(e){const t=(e.id||"").toLowerCase(),n=(e.name||"").toLowerCase(),o=(e.placeholder||"").toLowerCase();return!!(t==="resolving_input"||n==="account"||n==="accountid"||o.includes("account id")||o.includes("account alias"))}const xt=/new|signup|sign-up|register|create|confirm|repeat|retype|verify/i;function Ne(e,t=!1){const n=(e.autocomplete||"").toLowerCase();if(n.includes("new-password"))return!0;if(n.includes("current-password"))return!1;const o=[e.name,e.id,e.placeholder,e.ariaLabel].filter(Boolean).join(" ");return xt.test(o)?!0:t}function At(e,t,n=8,o=0){return{left:e.left+e.width-t-n-o,top:e.top+e.height/2-t/2}}function yt(e,t,n,o=8,s=6){const r=e.left+e.width-o,a=e.top+e.height/2,l=e.left+e.width-n*4;let c=1/0;for(const u of t){const b=u.left+u.width;u.width>e.width*.6||u.height>e.height+6||a<u.top-2||a>u.top+u.height+2||b<l||(c=Math.min(c,u.left))}if(c===1/0)return 0;const m=r-(c-s),i=Math.max(0,e.width-n-o*2);return Math.min(Math.max(0,m),i)}function wt(e,t,n,o=6){const s=e.top+e.height+o,r=e.top-t.height-o,a=s+t.height>n.height,l=r>=0,c=a&&l,m=c?r:s,i=Math.max(0,n.width-t.width-4);return{left:Math.min(Math.max(4,e.left),i),top:m,flipped:c}}function vt(e,t){return!(e.width<24||e.height<12||e.top+e.height<0||e.top>t.height||e.left+e.width<0||e.left>t.width)}const Me="abcdefghijklmnopqrstuvwxyz",Et="ABCDEFGHIJKLMNOPQRSTUVWXYZ",kt="0123456789",Ct="!@#$%^&*()-_=+[]{}:;,.?",Tt=new Set(["I","l","1","O","0","o","|"]),Re=8,St=128,Lt={length:20,lowercase:!0,uppercase:!0,digits:!0,symbols:!0,avoidAmbiguous:!1};function De(e){if(!Number.isInteger(e)||e<=0)throw new Error("randomInt: bound must be a positive integer");const t=Math.floor(4294967296/e)*e,n=new Uint32Array(1);let o=0;do crypto.getRandomValues(n),o=n[0];while(o>=t);return o%e}function Y(e,t){return t?Array.from(e).filter(n=>!Tt.has(n)).join(""):e}function _t(e){const t=[];return e.lowercase&&t.push(Y(Me,e.avoidAmbiguous)),e.uppercase&&t.push(Y(Et,e.avoidAmbiguous)),e.digits&&t.push(Y(kt,e.avoidAmbiguous)),e.symbols&&t.push(Y(Ct,e.avoidAmbiguous)),t.filter(n=>n.length>0)}function Oe(e){return e[De(e.length)]}function It(e){for(let t=e.length-1;t>0;t--){const n=De(t+1);[e[t],e[n]]=[e[n],e[t]]}return e}function Fe(e={}){const t={...Lt,...e},n=_t(t);n.length===0&&n.push(Y(Me,t.avoidAmbiguous));const o=Math.max(Re,Math.min(St,Math.floor(t.length)||Re)),s=n.join(""),r=n.slice(0,o).map(Oe);for(;r.length<o;)r.push(Oe(s));return It(r).join("")}const Pt={private_key:"Private key",ssh_private_key:"SSH private key",aws_access_key:"AWS access key",github_token:"GitHub token",stripe_key:"Stripe secret key",jwt:"JWT / bearer token",google_api_key:"Google API key",slack_token:"Slack token",llm_api_key:"AI provider API key",database_url:"Database connection string",env_secret:"Secret in .env / assignment",generic_secret:"High-entropy secret",password:"Password"},te={private_key:100,ssh_private_key:100,aws_access_key:90,github_token:90,stripe_key:90,google_api_key:88,slack_token:88,llm_api_key:86,jwt:84,database_url:80,env_secret:40,generic_secret:10,password:15},Nt=[{type:"private_key",re:/-----BEGIN (?:[A-Z0-9]+ )*PRIVATE KEY-----[\s\S]*?-----END (?:[A-Z0-9]+ )*PRIVATE KEY-----|-----BEGIN (?:[A-Z0-9]+ )*PRIVATE KEY-----/g,refine:e=>/OPENSSH/.test(e)?"ssh_private_key":"private_key"},{type:"jwt",re:/eyJ[A-Za-z0-9_-]{8,}\.eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}/g},{type:"aws_access_key",re:/\b(?:AKIA|ASIA|AROA|AIDA|AGPA|ANPA|ANVA|AIPA)[A-Z0-9]{16}\b/g},{type:"github_token",re:/\b(?:gh[posru]_[A-Za-z0-9]{36,255}|github_pat_[A-Za-z0-9_]{22,255})\b/g},{type:"stripe_key",re:/\b(?:sk|rk)_(?:live|test)_[A-Za-z0-9]{16,99}\b/g},{type:"google_api_key",re:/\bAIza[A-Za-z0-9_-]{35}\b/g},{type:"slack_token",re:/\bxox[baprs]-[A-Za-z0-9-]{10,}\b/g},{type:"llm_api_key",re:/\bsk-(?:ant-|proj-|svcacct-|admin-)?[A-Za-z0-9_-]{20,}\b/g},{type:"database_url",re:/\b(?:postgres(?:ql)?|mysql|mariadb|mongodb(?:\+srv)?|rediss?|amqps?):\/\/[^\s:@/]+:[^\s@/]+@\S+/g}],Mt=/^[ \t]*(?:export[ \t]+)?([A-Za-z_][A-Za-z0-9_]*)[ \t]*=[ \t]*(.+?)[ \t]*$/,Rt=/(pass|passwd|pwd|secret|token|api[_-]?key|apikey|access[_-]?key|private[_-]?key|auth|credential|client[_-]?secret|conn(?:ection)?[_-]?str|db[_-]?url|database[_-]?url)/i;function Dt(e){return/^(true|false|null|none|localhost|127\.0\.0\.1)$/i.test(e)||/^[0-9]+$/.test(e)||/^\$\{?[A-Za-z_]/.test(e)||/^(x{3,}|changeme|your[_-]|<.*>|\.\.\.|example|placeholder|todo|secret_here|redacted)/i.test(e)}function Ot(e){const t=e.replace(/\s+/g," ").trim();if(t.length<=8)return"•".repeat(Math.max(4,t.length));const n=t.slice(0,4),o=t.slice(-4);return`${n}…${o}`}function ze(e,t,n,o,s){e.push({type:t,label:Pt[t],start:n,end:o,value:s,preview:Ot(s)})}function Ft(e){const t=e.slice().sort((o,s)=>o.start-s.start||te[s.type]-te[o.type]),n=[];for(const o of t){const s=n[n.length-1];if(s&&o.start<s.end){te[o.type]>te[s.type]&&o.end-o.start>=s.end-s.start&&(n[n.length-1]=o);continue}n.push(o)}return n}const Be=1e5;function ue(e){const t=e.length>Be?e.slice(0,Be):e,n=[];for(const a of Nt){a.re.lastIndex=0;let l;for(;(l=a.re.exec(t))!==null;){if(l[0].length===0){a.re.lastIndex++;continue}const c=a.refine?a.refine(l[0]):a.type;ze(n,c,l.index,l.index+l[0].length,l[0])}}let o=0;for(const a of t.split(/\r?\n/)){const l=Mt.exec(a);if(l){const c=l[1];let m=l[2],i=a.indexOf(m,c.length);if(/^(['"]).*\1$/.test(m)&&(m=m.slice(1,-1),i+=1),m.length>0&&!/\s/.test(m)&&!Dt(m)&&Rt.test(c)&&m.length>=6){const w=o+i;ze(n,"env_secret",w,w+m.length,m)}}o+=a.length+1}const s=Ft(n),r=Array.from(new Set(s.map(a=>a.type)));return{matches:s,types:r}}function Z(e,t){if(t.length===0)return e;const n=t.slice().sort((r,a)=>r.start-a.start);let o="",s=0;for(const r of n)r.start<s||(o+=e.slice(s,r.start)+"[REDACTED]",s=r.end);return o+=e.slice(s),o}const zt=new Set(["co.uk","org.uk","gov.uk","ac.uk","me.uk","ltd.uk","plc.uk","co.jp","or.jp","ne.jp","ac.jp","go.jp","com.au","net.au","org.au","edu.au","gov.au","co.nz","org.nz","govt.nz","co.za","org.za","co.in","net.in","org.in","gov.in","ac.in","com.br","net.br","org.br","gov.br","com.cn","net.cn","org.cn","gov.cn","com.mx","com.tr","com.sg","com.hk","com.tw","com.ar","com.co","co.kr","or.kr","co.il","co.id","co.th","com.ua","com.ph","com.my"]),Bt=/^\d{1,3}(\.\d{1,3}){3}$/;function He(e){let t=(e||"").trim().toLowerCase();return t=t.replace(/\.+$/,""),t=t.replace(/^www\./,""),t}function Ht(e){const t=He(e);if(!t||t==="localhost"||Bt.test(t)||t.includes(":"))return t;const n=t.split(".").filter(Boolean);if(n.length<=2)return t;const o=n.slice(-2).join(".");return zt.has(o)?n.slice(-3).join("."):o}const jt=new Set(["openai.com","chatgpt.com","claude.ai","anthropic.com","perplexity.ai","poe.com","character.ai","you.com","phind.com","mistral.ai","cohere.com","deepseek.com","x.ai","groq.com","huggingface.co","replicate.com","together.ai","pi.ai","cursor.com","cursor.sh","v0.dev","bolt.new","lovable.dev","lmstudio.ai","ollama.com","replit.com","lmsys.org","kimi.ai","moonshot.cn","doubao.com","chatglm.cn","zhipuai.cn","baichuan-ai.com","baichuan-api.com","hailuoai.com","ababgroup.com","qwen.ai"]),$t=new Set(["gemini.google.com","bard.google.com","aistudio.google.com","notebooklm.google.com","copilot.microsoft.com","copilot.cloud.microsoft","m365.cloud.microsoft","duckduckgo.com","yiyan.baidu.com","tongyi.aliyun.com","qianwen.alibabacloud.com","hunyuan.tencent.com","xinghuo.xfyun.cn"]);function me(e){const t=He(e);return t?$t.has(t)?!0:jt.has(Ht(t)):!1}const ne={mode:"warn",allowDismiss:!0,scope:"ai_sites",source:"default"};function je(e){const t=e&&typeof e=="object"?e:{},n=t.mode==="off"||t.mode==="block"||t.mode==="warn"?t.mode:ne.mode,o=t.scope==="all_sites"?"all_sites":"ai_sites",s=t.source==="admin"||t.source==="user"?t.source:ne.source,r=n==="block"?!1:t.allowDismiss!==!1;return{mode:n,allowDismiss:r,scope:o,source:s}}function oe(e,t){return e.mode==="off"?!1:e.scope==="all_sites"||t==="localhost"||t==="127.0.0.1"||t==="[::1]"?!0:me(t)}const qt="xorapass-overlay-host",se=20,$e=260;let pe=null,re=null,q=null,F=[],D=null,U=null,ge=0;const Ut=`
:host { all: initial; }
.layer {
  position: fixed;
  inset: 0;
  /* The layer itself must not swallow page clicks; only its children opt in. */
  pointer-events: none;
  z-index: 2147483647;
  font-family: Inter, system-ui, -apple-system, sans-serif;
}
.icon {
  position: fixed;
  width: ${se}px;
  height: ${se}px;
  padding: 0;
  margin: 0;
  border: none;
  border-radius: 4px;
  background: transparent;
  cursor: pointer;
  pointer-events: auto;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: background-color 0.15s;
}
.icon:hover { background-color: rgba(45, 212, 191, 0.15); }
.icon:focus-visible { outline: 2px solid #2dd4bf; outline-offset: 1px; }
.menu {
  position: fixed;
  width: ${$e}px;
  background-color: #0f172a;
  border: 1px solid rgba(255, 255, 255, 0.08);
  border-radius: 10px;
  box-shadow: 0 10px 25px -5px rgba(0,0,0,0.5), 0 8px 24px rgba(45,212,191,0.15);
  overflow: hidden;
  pointer-events: auto;
  color: #e2e8f0;
}
.menu-header {
  padding: 8px 12px;
  font-size: 10px;
  font-weight: 700;
  color: #2dd4bf;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  border-bottom: 1px solid rgba(255,255,255,0.05);
  background-color: #0a1412;
}
.menu-warning {
  padding: 8px 12px;
  font-size: 10px;
  line-height: 1.4;
  color: #fca5a5;
  background-color: rgba(220, 38, 38, 0.12);
  border-bottom: 1px solid rgba(220, 38, 38, 0.25);
}
.menu-item {
  width: 100%;
  padding: 10px 12px;
  background: none;
  border: none;
  border-bottom: 1px solid rgba(255,255,255,0.03);
  cursor: pointer;
  display: block;
  text-align: left;
  color: #e2e8f0;
  font-family: inherit;
  transition: background-color 0.15s, color 0.15s;
}
.menu-item:hover, .menu-item:focus-visible {
  background-color: rgba(45, 212, 191, 0.08);
  color: #2dd4bf;
  outline: none;
}
.menu-item-label {
  font-weight: 600;
  font-size: 12px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.menu-item-user {
  font-size: 10px;
  color: #64748b;
  font-family: ui-monospace, monospace;
  margin-top: 2px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.suggest {
  padding: 10px 12px;
  border-bottom: 1px solid rgba(255, 255, 255, 0.06);
  background: rgba(45, 212, 191, 0.06);
}
.suggest-label {
  font-size: 9px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  color: #2dd4bf;
  margin-bottom: 6px;
}
.suggest-row { display: flex; align-items: center; gap: 8px; }
.suggest-value {
  flex: 1;
  min-width: 0;
  font-family: ui-monospace, monospace;
  font-size: 12px;
  color: #e2e8f0;
  word-break: break-all;
  line-height: 1.35;
}
.suggest-refresh {
  flex: none;
  width: 24px;
  height: 24px;
  display: flex;
  align-items: center;
  justify-content: center;
  border: 1px solid rgba(255, 255, 255, 0.12);
  background: transparent;
  color: #94a3b8;
  border-radius: 6px;
  cursor: pointer;
  font-size: 12px;
  font-family: inherit;
}
.suggest-refresh:hover { color: #2dd4bf; border-color: rgba(45, 212, 191, 0.4); }
.suggest-use {
  width: 100%;
  margin-top: 8px;
  padding: 7px 10px;
  font-size: 11px;
  font-weight: 700;
  color: #04231d;
  background: linear-gradient(135deg, #2dd4bf, #34d399);
  border: none;
  border-radius: 7px;
  cursor: pointer;
  font-family: inherit;
}

.save-prompt {
  position: fixed;
  top: 16px;
  right: 16px;
  width: 380px;
  max-width: calc(100vw - 32px);
  background: #ffffff;
  border: 1px solid rgba(15, 23, 42, 0.08);
  border-radius: 18px;
  box-shadow:
    0 1px 3px rgba(15, 23, 42, 0.06),
    0 8px 24px -4px rgba(15, 23, 42, 0.14),
    0 24px 48px -12px rgba(15, 23, 42, 0.18);
  pointer-events: auto;
  color: #0f172a;
  overflow: hidden;
  animation: xp-slide-in 0.35s cubic-bezier(0.34, 1.56, 0.64, 1);
}
.save-prompt.is-update {
  border-color: rgba(217, 119, 6, 0.18);
}
@keyframes xp-slide-in {
  from { transform: translateY(-12px) scale(0.97); opacity: 0; }
  to   { transform: translateY(0) scale(1); opacity: 1; }
}
@keyframes xp-slide-out {
  from { transform: translateY(0) scale(1); opacity: 1; }
  to   { transform: translateY(-8px) scale(0.97); opacity: 0; }
}
@keyframes xp-check-draw {
  0%   { stroke-dashoffset: 24; }
  100% { stroke-dashoffset: 0; }
}
@keyframes xp-check-circle {
  0%   { stroke-dashoffset: 100; }
  100% { stroke-dashoffset: 0; }
}
.save-head {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 16px 16px 0 18px;
}
.save-head-icon {
  display: flex;
  align-items: center;
  flex: none;
}
.save-title {
  font-size: 15px;
  font-weight: 700;
  flex: 1;
  letter-spacing: -0.01em;
  color: #0f172a;
}
.save-title.is-update { color: #92400e; }
.save-close {
  width: 28px;
  height: 28px;
  flex: none;
  display: flex;
  align-items: center;
  justify-content: center;
  border: none;
  background: transparent;
  border-radius: 7px;
  color: #94a3b8;
  cursor: pointer;
  font-size: 16px;
  line-height: 1;
  font-family: inherit;
  transition: background-color 0.15s, color 0.15s;
}
.save-close:hover { background: rgba(15, 23, 42, 0.06); color: #0f172a; }

.save-identity {
  display: flex;
  align-items: center;
  gap: 12px;
  margin: 14px 18px 0 18px;
  padding: 12px 14px;
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 12px;
  transition: border-color 0.15s;
}
.save-prompt.is-update .save-identity {
  background: rgba(251, 191, 36, 0.06);
  border-color: rgba(217, 119, 6, 0.18);
}
/* Favicon from Google's service, with letter-avatar fallback */
.save-favicon {
  width: 36px;
  height: 36px;
  flex: none;
  border-radius: 9px;
  object-fit: contain;
  background: #f1f5f9;
  border: 1px solid rgba(15, 23, 42, 0.06);
}
.save-avatar {
  width: 36px;
  height: 36px;
  flex: none;
  border-radius: 9px;
  background: linear-gradient(135deg, #0d9488, #059669);
  color: #ffffff;
  font-size: 15px;
  font-weight: 700;
  display: flex;
  align-items: center;
  justify-content: center;
  text-transform: uppercase;
}
.save-prompt.is-update .save-avatar {
  background: linear-gradient(135deg, #d97706, #b45309);
}
.save-identity-text { min-width: 0; flex: 1; }
.save-username {
  font-size: 14px;
  font-weight: 600;
  color: #0f172a;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.save-username.is-empty { color: #94a3b8; font-weight: 500; font-style: italic; }
.save-host {
  font-size: 12px;
  color: #64748b;
  margin-top: 2px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

/* Footer: brand logo left, action buttons right — mirrors LastPass layout */
.save-footer {
  display: flex;
  align-items: center;
  padding: 12px 16px 14px 18px;
  border-top: 1px solid rgba(15, 23, 42, 0.05);
  margin-top: 14px;
}
.save-brand {
  display: flex;
  align-items: center;
  gap: 0;
  flex: 1;
  min-width: 0;
}
.save-brand-logo {
  height: 22px;
  width: auto;
  object-fit: contain;
  display: block;
  user-select: none;
  -webkit-user-drag: none;
}
.save-actions {
  display: flex;
  align-items: center;
  gap: 8px;
  flex: none;
}
.save-btn {
  padding: 8px 18px;
  font-size: 13px;
  font-weight: 600;
  border-radius: 9px;
  cursor: pointer;
  font-family: inherit;
  transition: background-color 0.15s, box-shadow 0.15s, transform 0.1s;
}
.save-btn:active { transform: scale(0.97); }
.save-btn-primary {
  color: #ffffff;
  font-weight: 700;
  background: linear-gradient(135deg, #0d9488, #059669);
  border: none;
  box-shadow: 0 2px 8px rgba(13, 148, 136, 0.24);
}
.save-btn-primary:hover:not(:disabled) {
  box-shadow: 0 4px 14px rgba(13, 148, 136, 0.36);
  transform: translateY(-1px);
}
.save-btn-primary:disabled { opacity: 0.6; cursor: default; box-shadow: none; transform: none; }
.save-prompt.is-update .save-btn-primary {
  background: linear-gradient(135deg, #d97706, #b45309);
  box-shadow: 0 2px 8px rgba(217, 119, 6, 0.24);
}
.save-prompt.is-update .save-btn-primary:hover:not(:disabled) {
  box-shadow: 0 4px 14px rgba(217, 119, 6, 0.36);
}
.save-btn-secondary {
  color: #64748b;
  background: transparent;
  border: none;
}
.save-btn-secondary:hover { background: rgba(15, 23, 42, 0.05); color: #0f172a; }

/* "Never for this site" link — subtle, below actions (Bitwarden-inspired) */
.save-never {
  display: block;
  width: 100%;
  text-align: center;
  padding: 0 18px 12px 18px;
  font-size: 11px;
  color: #94a3b8;
  background: none;
  border: none;
  cursor: pointer;
  font-family: inherit;
  transition: color 0.15s;
}
.save-never:hover { color: #ef4444; }

/* Error status banner */
.save-status {
  margin: 10px 18px 0 18px;
  padding: 9px 12px;
  font-size: 12px;
  line-height: 1.4;
  color: #9a3412;
  background: rgba(234, 88, 12, 0.06);
  border: 1px solid rgba(234, 88, 12, 0.16);
  border-radius: 9px;
}

/* Success overlay — 1Password-style confirmation before auto-dismiss */
.save-success {
  position: absolute;
  inset: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 10px;
  background: #ffffff;
  border-radius: 18px;
  z-index: 1;
  animation: xp-slide-in 0.2s ease-out;
}
.save-success-icon {
  width: 48px;
  height: 48px;
}
.save-success-icon circle {
  fill: none;
  stroke: #059669;
  stroke-width: 2;
  stroke-dasharray: 100;
  stroke-dashoffset: 100;
  animation: xp-check-circle 0.4s ease-out forwards;
}
.save-success-icon polyline {
  fill: none;
  stroke: #059669;
  stroke-width: 2.5;
  stroke-linecap: round;
  stroke-linejoin: round;
  stroke-dasharray: 24;
  stroke-dashoffset: 24;
  animation: xp-check-draw 0.3s 0.25s ease-out forwards;
}
.save-success-text {
  font-size: 14px;
  font-weight: 600;
  color: #059669;
}

.backdrop {
  position: fixed;
  top: 16px;
  right: 16px;
  z-index: 2147483647;
  pointer-events: auto;
}
.backdrop.is-closing {
  animation: xp-slide-out 0.2s cubic-bezier(0.4, 0, 0.2, 1) forwards;
}
.modal {
  width: 380px;
  max-width: calc(100vw - 32px);
  background-color: #ffffff;
  border: 1px solid rgba(15, 23, 42, 0.08);
  border-radius: 18px;
  box-shadow:
    0 2px 4px rgba(15, 23, 42, 0.04),
    0 10px 28px -4px rgba(15, 23, 42, 0.16),
    0 24px 48px -12px rgba(15, 23, 42, 0.18);
  overflow: hidden;
  color: #0f172a;
  animation: xp-slide-in 0.35s cubic-bezier(0.34, 1.56, 0.64, 1);
}
.modal-head {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 16px 16px 12px 18px;
}
.modal-close {
  width: 26px;
  height: 26px;
  flex: none;
  display: flex;
  align-items: center;
  justify-content: center;
  border: none;
  background: transparent;
  border-radius: 7px;
  color: #94a3b8;
  cursor: pointer;
  font-size: 18px;
  line-height: 1;
  font-family: inherit;
  margin-left: auto;
  transition: background-color 0.15s, color 0.15s;
}
.modal-close:hover {
  background: rgba(15, 23, 42, 0.06);
  color: #0f172a;
}
.modal-head-icon {
  width: 36px;
  height: 36px;
  border-radius: 10px;
  background: rgba(245, 158, 11, 0.12);
  border: 1px solid rgba(245, 158, 11, 0.25);
  display: flex;
  align-items: center;
  justify-content: center;
  flex: none;
}
.modal-head-icon.is-danger {
  background: rgba(225, 29, 72, 0.12);
  border-color: rgba(225, 29, 72, 0.25);
}
.modal-title {
  font-size: 15px;
  font-weight: 700;
  color: #0f172a;
  letter-spacing: -0.01em;
  line-height: 1.3;
}
.modal-body {
  padding: 0 22px 18px 22px;
  font-size: 13px;
  line-height: 1.55;
  color: #475569;
}
.modal-body-line {
  margin: 0 0 8px 0;
  color: #334155;
  font-size: 13px;
  display: flex;
  align-items: flex-start;
  gap: 8px;
}
.modal-body-line:last-child {
  margin-bottom: 0;
}
.modal-body-bullet {
  color: #94a3b8;
  font-size: 14px;
  line-height: 1;
  margin-top: 3px;
}
.modal-preview {
  margin-top: 10px;
  padding: 10px 14px;
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 12px;
  font-size: 12px;
  line-height: 1.45;
  word-break: break-all;
}
.modal-preview-label {
  font-weight: 700;
  color: #64748b;
  font-family: Inter, system-ui, sans-serif;
  margin-right: 6px;
}
.modal-preview-value {
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
  color: #0f172a;
  font-weight: 600;
}
.modal-actions {
  display: flex;
  gap: 10px;
  padding: 14px 22px 18px 22px;
  background: #fafafa;
  border-top: 1px solid #f1f5f9;
  justify-content: flex-end;
  align-items: center;
}
.btn {
  padding: 9px 18px;
  font-size: 12.5px;
  font-weight: 600;
  border-radius: 10px;
  cursor: pointer;
  font-family: inherit;
  transition: all 0.15s ease;
  outline: none;
}
.btn-cancel {
  color: #334155;
  background: #ffffff;
  border: 1px solid #cbd5e1;
  box-shadow: 0 1px 2px rgba(15, 23, 42, 0.05);
}
.btn-cancel:hover {
  background: #f1f5f9;
  color: #0f172a;
  border-color: #94a3b8;
}
.btn-confirm {
  color: #ffffff;
  background: linear-gradient(135deg, #0d9488, #059669);
  border: none;
  font-weight: 700;
  box-shadow: 0 2px 8px rgba(13, 148, 136, 0.25);
}
.btn-confirm:hover {
  opacity: 0.95;
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(13, 148, 136, 0.35);
}
.btn-confirm:active {
  transform: translateY(0);
}
`,fe='<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#2dd4bf" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>';function ae(){if(q&&re)return q;const e=document.createElement("div");e.id=qt,e.setAttribute("style","all: initial; position: static;"),re=e.attachShadow({mode:"closed"});const t=document.createElement("style");return t.textContent=Ut,re.appendChild(t),q=document.createElement("div"),q.className="layer",re.appendChild(q),document.documentElement.appendChild(e),pe=e,q}function he(e,t){if(F.some(s=>s.input===e))return!1;const n=ae(),o=document.createElement("button");return o.type="button",o.className="icon",o.setAttribute("aria-label","XoraPass autofill"),o.innerHTML=fe,o.addEventListener("mousedown",s=>{s.preventDefault(),s.stopPropagation()}),o.addEventListener("click",s=>{s.preventDefault(),s.stopPropagation(),t()}),n.appendChild(o),F.push({input:e,icon:o,onActivate:t}),be(),!0}function Vt(e,t){const o=(e.closest("form, label, div, span")||e.parentElement||document.body).querySelectorAll('button, [role="button"], a, svg, img, i, span[class]'),s=[];for(const r of o){if(r===e||r.contains(e))continue;const a=r.getBoundingClientRect();if(!(a.width===0||a.height===0)&&!(a.left<t.left+t.width/2)&&(s.push({top:a.top,left:a.left,width:a.width,height:a.height}),s.length>=12))break}return s}function be(){const e={width:window.innerWidth,height:window.innerHeight};F=F.filter(t=>t.input.isConnected?!0:(t.icon.remove(),U===t.input&&O(),!1));for(const t of F){const n=t.input.getBoundingClientRect();if(!(!t.input.disabled&&!t.input.readOnly)||!vt(n,e)){t.icon.style.display="none";continue}(t.offset===void 0||Math.abs((t.offsetAtWidth??-1)-n.width)>1)&&(t.offset=yt(n,Vt(t.input,n),se),t.offsetAtWidth=n.width);const s=At(n,se,8,t.offset);t.icon.style.display="flex",t.icon.style.left=`${s.left}px`,t.icon.style.top=`${s.top}px`}if(D&&U){if(!U.isConnected){O();return}const t=U.getBoundingClientRect(),n=D.offsetHeight||0,o=wt(t,{width:$e,height:n},e);D.style.left=`${o.left}px`,D.style.top=`${o.top}px`}}function xe(){ge||(ge=requestAnimationFrame(()=>{ge=0,be()}))}function qe(e,t){O();const n=ae(),o=document.createElement("div");o.className="menu",o.setAttribute("role","listbox");const s=document.createElement("div");if(s.className="menu-header",s.textContent="XoraPass Autofill",o.appendChild(s),t.warning){const r=document.createElement("div");r.className="menu-warning",r.textContent=`⚠ ${t.warning}`,o.appendChild(r)}if(t.suggestion){const r=t.suggestion,a=document.createElement("div");a.className="suggest";const l=document.createElement("div");l.className="suggest-label",l.textContent="Suggested password",a.appendChild(l);const c=document.createElement("div");c.className="suggest-row";const m=document.createElement("div");m.className="suggest-value",m.textContent=r.password,c.appendChild(m);const i=document.createElement("button");i.type="button",i.className="suggest-refresh",i.setAttribute("aria-label","Generate another"),i.textContent="⟳",i.addEventListener("mousedown",b=>b.preventDefault()),i.addEventListener("click",b=>{b.preventDefault(),b.stopPropagation(),m.textContent=r.onRegenerate()}),c.appendChild(i),a.appendChild(c);const u=document.createElement("button");u.type="button",u.className="suggest-use",u.textContent="Use this password",u.addEventListener("mousedown",b=>b.preventDefault()),u.addEventListener("click",b=>{b.preventDefault(),b.stopPropagation(),O(),r.onUse(m.textContent||r.password)}),a.appendChild(u),o.appendChild(a)}for(const r of t.credentials){const a=document.createElement("button");a.type="button",a.className="menu-item",a.setAttribute("role","option");const l=document.createElement("div");l.className="menu-item-label",l.textContent=r.label,a.appendChild(l);const c=document.createElement("div");c.className="menu-item-user",c.textContent=r.username,a.appendChild(c),a.addEventListener("mousedown",m=>m.preventDefault()),a.addEventListener("click",m=>{m.preventDefault(),m.stopPropagation(),O(),t.onPick(r.id)}),o.appendChild(a)}n.appendChild(o),D=o,U=e,be(),document.addEventListener("mousedown",Ue,!0),document.addEventListener("keydown",Ve,!0)}function O(){D&&(D.remove(),D=null),U=null,document.removeEventListener("mousedown",Ue,!0),document.removeEventListener("keydown",Ve,!0)}function Gt(){return D!==null}function Ue(e){pe&&e.composedPath().includes(pe)||O()}function Ve(e){e.key==="Escape"&&(e.stopPropagation(),O())}function V(e){const t=ae();return new Promise(n=>{const o=document.createElement("div");o.className="backdrop";const s=document.createElement("div");s.className="modal",s.setAttribute("role","alertdialog"),s.setAttribute("aria-modal","true");const r=document.createElement("div");r.className="modal-head";const a=e.title.toLowerCase().includes("block"),l=document.createElement("div");l.className=a?"modal-head-icon is-danger":"modal-head-icon",l.innerHTML=a?'<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#e11d48" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>':'<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#d97706" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',r.appendChild(l);const c=document.createElement("div");c.className="modal-title",c.textContent=e.title,r.appendChild(c);const m=document.createElement("button");m.type="button",m.className="modal-close",m.innerHTML="×",m.title="Dismiss",m.addEventListener("click",()=>b(!1)),r.appendChild(m),s.appendChild(r);const i=document.createElement("div");i.className="modal-body";for(const h of e.body)if(h.startsWith("Preview:")){const E=document.createElement("div");E.className="modal-preview";const k=document.createElement("span");k.className="modal-preview-label",k.textContent="Preview:",E.appendChild(k);const y=document.createElement("span");y.className="modal-preview-value",y.textContent=h.replace(/^Preview:\s*/,""),E.appendChild(y),i.appendChild(E)}else{const E=document.createElement("div");E.className="modal-body-line";const k=document.createElement("span");k.className="modal-body-bullet",k.textContent="•",E.appendChild(k);const y=document.createElement("span");y.textContent=h,E.appendChild(y),i.appendChild(E)}s.appendChild(i);const u=document.createElement("div");u.className="modal-actions";const b=h=>{o.classList.add("is-closing"),setTimeout(()=>o.remove(),150),document.removeEventListener("keydown",g,!0),n(h)};if(e.cancelLabel){const h=document.createElement("button");h.type="button",h.className="btn btn-cancel",h.textContent=e.cancelLabel,h.addEventListener("click",()=>b(!1)),u.appendChild(h)}const w=document.createElement("button");w.type="button",w.className="btn btn-confirm",w.textContent=e.confirmLabel,w.addEventListener("click",()=>b(!0)),u.appendChild(w),s.appendChild(u),o.appendChild(s),o.addEventListener("click",h=>{h.target===o&&b(!1)});const g=h=>{h.key==="Escape"&&(h.stopPropagation(),b(!1))};document.addEventListener("keydown",g,!0),t.appendChild(o),w.focus()})}let X=null;const Wt='<svg class="save-success-icon" viewBox="0 0 40 40"><circle cx="20" cy="20" r="18"/><polyline points="12,20 18,26 28,14"/></svg>';function Yt(e){K();const t=ae(),n=document.createElement("div");n.className=e.mode==="update"?"save-prompt is-update":"save-prompt",n.setAttribute("role","dialog"),n.setAttribute("aria-label","Save login to XoraPass"),n.style.position="fixed";const o=()=>{e.onDismiss(),K()},s=document.createElement("div");s.className="save-head";const r=document.createElement("span");r.className="save-head-icon",r.innerHTML=fe;const a=document.createElement("div");a.className=e.mode==="update"?"save-title is-update":"save-title",a.textContent=e.mode==="update"?"Update password?":"Save this login?";const l=document.createElement("button");l.type="button",l.className="save-close",l.setAttribute("aria-label","Dismiss"),l.textContent="✕",l.addEventListener("click",o),s.appendChild(r),s.appendChild(a),s.appendChild(l),n.appendChild(s);const c=document.createElement("div");c.className="save-identity";const m=e.hostname.replace(/^www\./,""),i=document.createElement("img");i.className="save-favicon",i.alt=m,i.src=`https://www.google.com/s2/favicons?domain=${encodeURIComponent(m)}&sz=64`,i.onerror=()=>{const f=document.createElement("div");f.className="save-avatar",f.textContent=(m[0]||"?").toUpperCase(),i.replaceWith(f)},c.appendChild(i);const u=document.createElement("div");u.className="save-identity-text";const b=document.createElement("div");b.className=e.username?"save-username":"save-username is-empty",b.textContent=e.username||"No username detected",u.appendChild(b);const w=document.createElement("div");w.className="save-host",w.textContent=m,u.appendChild(w),c.appendChild(u),n.appendChild(c);const g=document.createElement("div");g.className="save-footer";const h=document.createElement("div");if(h.className="save-brand",e.brandLogoUrl){const f=document.createElement("img");f.className="save-brand-logo",f.src=e.brandLogoUrl,f.alt="XoraPass",f.draggable=!1,h.appendChild(f)}else{const f=document.createElement("span");f.className="save-brand-icon",f.innerHTML=fe;const M=document.createElement("span");M.className="save-brand-name",M.textContent="XoraPass",h.appendChild(f),h.appendChild(M)}g.appendChild(h);const E=document.createElement("div");E.className="save-actions";const k=document.createElement("button");k.type="button",k.className="save-btn save-btn-secondary",k.textContent="Not now",k.addEventListener("click",o);const y=document.createElement("button");if(y.type="button",y.className="save-btn save-btn-primary",y.textContent=e.mode==="update"?"Update":"Save",y.addEventListener("click",async()=>{y.disabled=!0,k.disabled=!0,y.textContent="Saving…";const f=await e.onSave();if(f&&f.success){const H=document.createElement("div");H.className="save-success",H.innerHTML=Wt;const d=document.createElement("div");d.className="save-success-text",d.textContent=e.mode==="update"?"Updated!":"Saved!",H.appendChild(d),n.style.position="fixed",n.appendChild(H),setTimeout(()=>{n.style.animation="xp-slide-out 0.2s ease-in forwards",setTimeout(K,200)},800);return}y.disabled=!1,k.disabled=!1,y.textContent=e.mode==="update"?"Update":"Save";const M=n.querySelector(".save-status")||document.createElement("div");M.className="save-status",M.textContent=f?.detail?f.detail:f?.error==="session_expired"?"Your session expired. Unlock XoraPass and try again.":f?.error==="locked"?"XoraPass is locked. Unlock it and try again.":f?.error==="offline"?"You're offline. Reconnect and unlock XoraPass to save this.":"Couldn't save. Please try again.",M.isConnected||n.insertBefore(M,g)}),E.appendChild(k),E.appendChild(y),g.appendChild(E),n.appendChild(g),e.onNever){const f=document.createElement("button");f.type="button",f.className="save-never",f.textContent="Never for this site",f.addEventListener("click",()=>{e.onNever(),K()}),n.appendChild(f)}t.appendChild(n),X=n}function K(){X&&(X.remove(),X=null)}function Zt(){return X!==null}function Ae(){O();for(const e of F)e.icon.remove();F=[]}function ye(e){return F.some(t=>t.input===e)}let z=[],j=null;const we=new WeakMap,Ge=new WeakMap,ie=new WeakMap;let N=ne,We=!1;const G=new Set;let J=null;const Xt=new Set(["card","identity"]);function Ye(e){return(e||"").replace(/[&<>"]|'/g,t=>{switch(t){case"&":return"&amp;";case"<":return"&lt;";case">":return"&gt;";case'"':return"&quot;";default:return"&#39;"}})}function Kt(){if(window.top===window.self)return{isTop:!0,isCrossOriginFrame:!1};let t=!0;try{t=window.top?.location.origin!==window.location.origin}catch{t=!0}try{const n=window.location.ancestorOrigins;if(n&&n.length){for(let o=0;o<n.length;o++)if(n[o]!==window.location.origin){t=!0;break}}}catch{}return{isTop:!1,isCrossOriginFrame:t}}function Ze(){if(window.location.protocol!=="http:")return!1;const e=window.location.hostname;return e!=="localhost"&&e!=="127.0.0.1"&&e!=="[::1]"}function le(){const e=window.location.hostname;C.runtime.sendMessage({type:"GET_MATCHING_CREDENTIALS",payload:{hostname:e}}).then(t=>{if(t){if(t.disabled){z=[],Ae();return}j=t.lookalike||null,z=t.credentials||[],Ae(),Ke()}}).catch(()=>{})}function Xe(){const e=window.location.hostname;C.runtime.sendMessage({type:"AI_CHECK_TAB",payload:{hostname:e}}).then(t=>{t&&t.offer?Je(t.offer):$()}).catch(()=>{})}C.runtime.onMessage.addListener(e=>{!e||typeof e.type!="string"||e.type==="AI_FILL_AVAILABLE"&&Je(e.payload)});function B(e){return!e||e.type==="hidden"||e.disabled||e.readOnly?!1:e.offsetParent!==null||e.getClientRects().length>0}function Ke(){const t=Array.from(document.querySelectorAll('input[type="password"]')).filter(B),n=t.length>1;for(const o of t){const s=Ne({autocomplete:o.getAttribute("autocomplete"),name:o.name,id:o.id,placeholder:o.getAttribute("placeholder"),ariaLabel:o.getAttribute("aria-label")},n);if(!s&&z.length===0||ye(o))continue;Ge.set(o,s);const r=ve(o);we.set(o,r),he(o,()=>Ee(o,o)),ie.set(o,o),r&&!ye(r)&&(we.set(r,r),he(r,()=>Ee(o,r)),ie.set(r,o))}if(window.location.hostname.endsWith("aws.amazon.com")&&z.length>0){const s=Array.from(document.querySelectorAll("input")).find(r=>B(r)&&Pe({type:r.type,name:r.name,id:r.id,placeholder:r.getAttribute("placeholder"),ariaLabel:r.getAttribute("aria-label")}));s&&!ye(s)&&(he(s,()=>{qe(s,{credentials:z,warning:null,onPick:async r=>{const a=z.find(g=>g.id===r);if(!a||!await et(a))return;const c=await C.runtime.sendMessage({type:"GET_CREDENTIAL_SECRET",payload:{id:r}}).catch(()=>null);if(!c||c.error){console.warn("[XoraPass] Fill refused:",c?.error||"no_response");return}const m=c.accountId||c.username||"";_(s,m);const i=Array.from(document.querySelectorAll("input")),u=i.find(g=>g!==s&&g.type!=="password"&&g.type!=="hidden"&&(g.id==="username"||g.name==="username"||g.id?.toLowerCase().includes("username")||g.name?.toLowerCase().includes("username"))),b=i.find(g=>g.type==="password"&&B(g));if(u&&c.username&&_(u,c.username),b&&c.value&&_(b,c.value),!Array.from(document.querySelectorAll('input[type="password"]')).some(B)){const g=s.form,h=g?.querySelector('button[type="submit"], input[type="submit"]')||(g?null:document.querySelector('button[type="submit"], input[type="submit"]'));g&&typeof g.requestSubmit=="function"?g.requestSubmit(h):h instanceof HTMLElement&&h.click()}}})}),ie.set(s,s))}}function ve(e){const t=e.form||document,n=Array.from(t.querySelectorAll("input")),o=n.indexOf(e);if(o===-1)return null;let s=null;for(let r=o-1;r>=0;r--){const a=n[r];if(!B(a))continue;const l=(a.type||"text").toLowerCase();if(l!=="password"&&l!=="hidden"&&l!=="submit"&&l!=="button"&&l!=="checkbox"&&l!=="radio"&&(s||(s=a)),de({type:a.type,autocomplete:a.getAttribute("autocomplete"),name:a.name,id:a.id,placeholder:a.getAttribute("placeholder"),ariaLabel:a.getAttribute("aria-label")}))return a}return s}function Ee(e,t){const n=Ge.get(e)===!0;qe(t,{credentials:z,warning:j?`This site resembles "${j.target}". Verify the address before filling.`:null,onPick:o=>void Qt(o,e),suggestion:n?{password:Fe(),onRegenerate:()=>Fe(),onUse:o=>Jt(e,o)}:void 0})}function Jt(e,t){_(e,t);const n=Array.from(document.querySelectorAll('input[type="password"]')).filter(o=>o!==e&&B(o)&&!o.value);for(const o of n)Ne({autocomplete:o.getAttribute("autocomplete"),name:o.name,id:o.id,placeholder:o.getAttribute("placeholder"),ariaLabel:o.getAttribute("aria-label")},!0)&&_(o,t)}async function Qt(e,t){const n=z.find(a=>a.id===e);if(!n||!await et(n))return;const s=await C.runtime.sendMessage({type:"GET_CREDENTIAL_SECRET",payload:{id:e}}).catch(()=>null);if(!s||s.error||typeof s.value!="string"){console.warn("[XoraPass] Fill refused:",s?.error||"no_response");return}if(n.category==="aws"||window.location.hostname.endsWith("aws.amazon.com")){const a=Array.from(document.querySelectorAll("input")),l=a.find(i=>Pe({type:i.type,name:i.name,id:i.id,placeholder:i.getAttribute("placeholder"),ariaLabel:i.getAttribute("aria-label")})),c=a.find(i=>i!==l&&i.type!=="password"&&i.type!=="hidden"&&(i.id==="username"||i.name==="username"||i.id?.toLowerCase().includes("username")||i.name?.toLowerCase().includes("username")||de({type:i.type,autocomplete:i.getAttribute("autocomplete"),name:i.name,id:i.id,placeholder:i.getAttribute("placeholder"),ariaLabel:i.getAttribute("aria-label")})));l&&s.accountId&&_(l,s.accountId);const m=s.username||"";c&&m&&_(c,m),_(t,s.value);return}const r=we.get(t)??null;r&&r!==t&&s.username&&_(r,s.username),_(t,s.value)}function $(){J?.remove(),J=null}function Je(e){if(J&&J.dataset.sessionId===e.sessionId)return;$();const t=document.createElement("div");t.dataset.sessionId=e.sessionId,Object.assign(t.style,{position:"fixed",top:"0",left:"0",right:"0",zIndex:"2147483647",display:"flex",alignItems:"center",flexWrap:"wrap",gap:"10px",padding:"10px 16px",background:"linear-gradient(90deg, #312e81, #3730a3)",borderBottom:"1px solid rgba(129, 140, 248, 0.4)",boxShadow:"0 4px 20px rgba(49, 46, 129, 0.4)",fontFamily:"Inter, system-ui, sans-serif",fontSize:"13px",color:"#e0e7ff"});const n=document.createElement("span");n.innerHTML=`ðŸ¤– <b>${Ye(e.aiToolName)}</b> was approved to ${Ye(e.action)} on this page â€” fill now?`,n.style.flex="1",n.style.minWidth="200px",t.appendChild(n);const o=(l,c,m)=>{const i=document.createElement("button");return i.type="button",i.innerText=l,Object.assign(i.style,{padding:"6px 14px",fontSize:"12px",fontWeight:"700",color:m,background:c,border:"none",borderRadius:"8px",cursor:"pointer"}),i},s=o("Fill","linear-gradient(90deg, #818cf8, #6366f1)","#0f172a");if(s.addEventListener("click",()=>void Qe(e,!1)),t.appendChild(s),e.grantedScopes.includes("submit")){const l=o("Fill & Submit","rgba(255,255,255,0.15)","#e0e7ff");l.addEventListener("click",()=>void Qe(e,!0)),t.appendChild(l)}const r=o("Not now","rgba(255,255,255,0.08)","#c7d2fe");r.addEventListener("click",()=>{C.runtime.sendMessage({type:"AI_FILL_HANDLED",payload:{sessionId:e.sessionId}}).catch(()=>{}),$()}),t.appendChild(r);const a=o("Revoke access","transparent","#fca5a5");a.style.textDecoration="underline",a.addEventListener("click",()=>{C.runtime.sendMessage({type:"AI_REVOKE_SESSION",payload:{sessionId:e.sessionId}}).catch(()=>{}),$()}),t.appendChild(a),document.documentElement.appendChild(t),J=t}async function Qe(e,t){const n=[];if(Ze()&&n.push("This page is served over insecure HTTP. Data you enter can be intercepted."),j&&n.push(`The address of this page resembles "${j.target}" but does not match it.`),n.length>0&&!await V({title:"Confirm AI-approved autofill",body:n,confirmLabel:"Fill anyway",cancelLabel:"Cancel"}))return;const s=Array.from(document.querySelectorAll('input[type="password"]')).find(B);if(!s){$();return}const r=ve(s),a=await C.runtime.sendMessage({type:"AI_FILL_CONFIRM",payload:{sessionId:e.sessionId}}).catch(()=>null);if(!a||a.error){$();return}if(r&&a.username&&_(r,a.username),_(s,a.value),t){const l=s.form,c=l?.querySelector('button[type="submit"], input[type="submit"]')||(l?null:document.querySelector('button[type="submit"], input[type="submit"]'));l&&typeof l.requestSubmit=="function"?l.requestSubmit(c):c instanceof HTMLElement&&c.click()}C.runtime.sendMessage({type:"AI_FILL_HANDLED",payload:{sessionId:e.sessionId}}).catch(()=>{}),$()}async function et(e){const t=[];return Xt.has(e.category)&&t.push(`You are about to autofill sensitive ${e.category} details ("${e.label}").`),Ze()&&t.push("This page is served over insecure HTTP. Data you enter can be intercepted."),j&&t.push(`The address of this page resembles "${j.target}" but does not match it.`),t.length===0?!0:V({title:"Confirm autofill",body:t,confirmLabel:"Fill anyway",cancelLabel:"Cancel"})}function _(e,t){const n=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,"value")?.set;n?n.call(e,t):e.value=t,e.dispatchEvent(new Event("input",{bubbles:!0})),e.dispatchEvent(new Event("change",{bubbles:!0})),e.dispatchEvent(new Event("blur",{bubbles:!0}))}let tt="";function en(e){const t=Array.from(e.querySelectorAll('input[type="password"]')),n=t.find(r=>r.value&&B(r));return!n||new Set(t.filter(r=>r.value).map(r=>r.value)).size>1?null:{username:ve(n)?.value||"",password:n.value}}function ke(e){const t=en(e);if(!t)return;const n=`${t.username}\0${t.password}`;n!==tt&&(tt=n,C.runtime.sendMessage({type:"CAPTURE_CREDENTIAL",payload:t}).then(o=>{o&&o.prompt&&setTimeout(nt,1200)}).catch(()=>{}))}function nt(){Zt()||C.runtime.sendMessage({type:"GET_PENDING_SAVE"}).then(e=>{const t=e&&e.pending;t&&Yt({username:t.username,hostname:t.hostname,mode:t.mode,brandLogoUrl:C.runtime.getURL("xorapass_logo_horizontal.png"),onSave:()=>C.runtime.sendMessage({type:"SAVE_CREDENTIAL"}).then(n=>(n&&n.success&&le(),n||{error:"no_response"})),onDismiss:()=>{C.runtime.sendMessage({type:"DISMISS_PENDING_SAVE"})},onNever:()=>{C.runtime.sendMessage({type:"DISMISS_PENDING_SAVE"}),C.runtime.sendMessage({type:"SET_SITE_DISABLED",payload:{hostname:t.hostname,disabled:!0}}),Ae()}})}).catch(()=>{})}let ot="";function tn(){document.addEventListener("change",e=>{const t=e.target;if(!(t instanceof HTMLInputElement))return;const n=t.value.trim();!n||n===ot||!de({type:t.type,autocomplete:t.getAttribute("autocomplete"),name:t.name,id:t.id,placeholder:t.getAttribute("placeholder"),ariaLabel:t.getAttribute("aria-label")})||(ot=n,C.runtime.sendMessage({type:"REMEMBER_USERNAME",payload:{username:n}}).catch(()=>{}))},!0)}function nn(){document.addEventListener("submit",e=>{const t=e.target;t&&t instanceof HTMLFormElement&&ke(t)},!0),document.addEventListener("click",e=>{const t=e.target;!t||!t.closest('button, [type="submit"], [role="button"]')||ke(document)},!0),document.addEventListener("keydown",e=>{if(e.key!=="Enter")return;const t=e.target;t instanceof HTMLInputElement&&t.type==="password"&&t.value&&ke(t.form||document)},!0)}function on(){document.addEventListener("focusin",e=>{const t=e.target;if(!(t instanceof HTMLInputElement))return;const n=ie.get(t);n&&(Gt()||t.value||Ee(n,t))},!0)}async function sn(){try{const e=await C.runtime.sendMessage({type:"AI_PASTE_POLICY"});e?.policy&&(N=je(e.policy))}catch{N=ne}}function st(e){if(e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement)return{kind:"text",start:e.selectionStart??e.value.length,end:e.selectionEnd??e.value.length};const t=window.getSelection();return!t||t.rangeCount===0?null:{kind:"contenteditable",range:t.getRangeAt(0).cloneRange()}}function Ce(e,t,n){if(e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement){if(e.focus(),n?.kind==="text"&&typeof n.start=="number"&&typeof n.end=="number")e.setRangeText(t,n.start,n.end,"end");else{const o=e.selectionStart??e.value.length,s=e.selectionEnd??e.value.length;e.setRangeText(t,o,s,"end")}e.dispatchEvent(new Event("input",{bubbles:!0}));return}if(n?.kind==="contenteditable"&&n.range){e.focus();const o=window.getSelection();if(o){o.removeAllRanges(),o.addRange(n.range),document.execCommand("insertText",!1,t);return}}e.focus(),document.execCommand("insertText",!1,t)}function rt(e){const t=s=>s instanceof HTMLInputElement||s instanceof HTMLTextAreaElement||s.isContentEditable,n=e.composedPath?e.composedPath():[];for(const s of n)if(s instanceof HTMLElement&&t(s))return s;const o=document.activeElement;return o instanceof HTMLElement&&t(o)?o:null}function Te(e){return e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement||e.isContentEditable}function at(e){if(!(e instanceof HTMLElement))return null;if(Te(e))return e;const t=e.closest('input, textarea, [contenteditable=""], [contenteditable="true"], [contenteditable="plaintext-only"]');return t instanceof HTMLElement?t:null}const rn=650;let Se;const ce=new WeakMap,it=new WeakMap;function Le(e){return Te(e)?e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement?e.value||"":e.textContent||e.innerText||"":""}function lt(e,t){if(Te(e)){if(e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement){const n=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,"value")?.set||Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,"value")?.set;n?n.call(e,t):e.value=t}else e.textContent=t;e.dispatchEvent(new Event("input",{bubbles:!0})),e.dispatchEvent(new Event("change",{bubbles:!0}))}}function an(e){const t=Le(e);t&&ce.set(e,t)}async function ct(e,t,n){const o=window.location.hostname;let s=n,r;if(s.matches.every(i=>G.has(i.value)))return;try{const i=await C.runtime.sendMessage({type:"GET_COPIED_SECRET"}),u=i?.secret,b=i?.id,w=i?.field;if(u&&t.includes(u)){r=b||void 0;const g=t.indexOf(u),h=g+u.length;let E="generic_secret";if(w==="password"?E="password":w==="privateKey"&&(E="private_key"),s.matches.some(y=>y.start===g&&y.end===h))for(const y of s.matches)y.start===g&&y.end===h&&(y.type=E,y.label=w==="password"?"Password":w==="privateKey"?"Private key":"Copied vault credential");else{const y={type:E,label:w==="password"?"Password":w==="privateKey"?"Private key":"Copied vault credential",start:g,end:h,value:u,preview:"••••••••"};s={matches:[...s.matches,y],types:Array.from(new Set([...s.types,E]))}}s.types=Array.from(new Set(s.matches.map(y=>y.type)))}}catch(i){console.debug("Failed to get copied secret",i)}if(s.matches.length===0)return;const l=Array.from(new Set(s.matches.map(i=>i.label)));if(N.mode==="block"||!N.allowDismiss){const i=ce.get(e)||"";lt(e,i),await V({title:"Secret typing blocked",body:[`XoraPass detected ${l.join(", ")} in what you entered.`,"Entering secrets into AI tools is blocked by policy.",`Preview: ${Z(t,n.matches).slice(0,120)}`],confirmLabel:"OK",cancelLabel:""});return}if(!await V({title:"Secret typing warning",body:[`XoraPass detected ${l.join(", ")} in what you entered.`,"This text is kept on-device. You can remove it, or keep it if you really want to.",`Preview: ${Z(t,s.matches).slice(0,120)}`],confirmLabel:"Keep anyway",cancelLabel:"Remove secret"}))lt(e,Z(t,s.matches));else{for(const i of s.matches)G.add(i.value);C.runtime.sendMessage({type:"AI_PASTE_EVENT",payload:{hostname:o,types:s.types,action:"type",isAiSite:me(o),vaultEntryId:r}}).catch(()=>{})}an(e)}function ln(){let e=document.activeElement;for(;e&&e.shadowRoot&&e.shadowRoot.activeElement;)e=e.shadowRoot.activeElement;return e}function cn(){const e=window.location.hostname;if(!oe(N,e))return;const t=ln();if(!t||!(t instanceof HTMLElement))return;const n=at(t);if(!n)return;const o=Le(n);if(!o||it.get(n)===o||(it.set(n,o),ce.get(n)===o))return;const s=ue(o);s.matches.length===0||s.matches.every(a=>G.has(a.value))||ct(n,o,s)}function dn(e){const t=window.location.hostname;if(!oe(N,t))return;const n=e.composedPath&&e.composedPath()[0]||e.target,o=at(n);o&&(Se&&clearTimeout(Se),Se=setTimeout(()=>{const s=Le(o);if(!s||ce.get(o)===s)return;const r=ue(s);r.matches.length===0||r.matches.every(l=>G.has(l.value))||ct(o,s,r)},rn))}async function dt(e,t,n,o){const s=window.location.hostname;let r=ue(t),a;try{const u=await C.runtime.sendMessage({type:"GET_COPIED_SECRET"}),b=u?.secret,w=u?.id,g=u?.field;if(b&&t.includes(b)){a=w||void 0;const h=t.indexOf(b),E=h+b.length;let k="generic_secret";if(g==="password"?k="password":g==="privateKey"&&(k="private_key"),r.matches.some(f=>f.start===h&&f.end===E))for(const f of r.matches)f.start===h&&f.end===E&&(f.type=k,f.label=g==="password"?"Password":g==="privateKey"?"Private key":"Copied vault credential");else{const f={type:k,label:g==="password"?"Password":g==="privateKey"?"Private key":"Copied vault credential",start:h,end:E,value:b,preview:"••••••••"};r={matches:[...r.matches,f],types:Array.from(new Set([...r.types,k]))}}r.types=Array.from(new Set(r.matches.map(f=>f.type)))}}catch(u){console.debug("Failed to get copied secret",u)}if(r.matches.every(u=>G.has(u.value))&&r.matches.length>0){e&&Ce(e,t,n);return}if(r.matches.length===0){e&&Ce(e,t,n);return}const c=Array.from(new Set(r.matches.map(u=>u.label)));if(N.mode==="block"||!N.allowDismiss){await V({title:"Secret paste blocked",body:[`XoraPass detected ${c.join(", ")} in what you tried to paste.`,"Pasting secrets into AI tools is blocked by policy.",`Preview: ${Z(t,r.matches).slice(0,120)}`],confirmLabel:"OK",cancelLabel:""});return}if(await V({title:"Secret paste warning",body:[`XoraPass detected ${c.join(", ")} in what you pasted.`,"This text is kept on-device. You can cancel, or continue if you really want to paste it here.",`Preview: ${Z(t,r.matches).slice(0,120)}`],confirmLabel:"Paste anyway",cancelLabel:"Cancel"})&&e){for(const u of r.matches)G.add(u.value);C.runtime.sendMessage({type:"AI_PASTE_EVENT",payload:{hostname:s,types:r.types,action:o,isAiSite:me(s),vaultEntryId:a}}).catch(()=>{}),Ce(e,t,n)}}function un(){We||(We=!0,sn(),C.storage.onChanged.addListener((e,t)=>{t==="local"&&e.pastePolicy?.newValue&&(N=je(e.pastePolicy.newValue))}),document.addEventListener("paste",e=>{if(Array.from(e.clipboardData?.types||[]).includes("Files")||e.clipboardData?.files&&e.clipboardData.files.length>0)return;const n=e.clipboardData?.getData("text/plain")||e.clipboardData?.getData("text")||"";if(!n)return;const o=window.location.hostname;if(!oe(N,o))return;e.preventDefault(),e.stopPropagation();const s=rt(e),r=s?st(s):null;dt(s,n,r,"paste")},!0),document.addEventListener("drop",e=>{if(Array.from(e.dataTransfer?.types||[]).includes("Files")||e.dataTransfer?.files&&e.dataTransfer.files.length>0)return;const n=e.dataTransfer?.getData("text/plain")||e.dataTransfer?.getData("text")||"";if(!n)return;const o=window.location.hostname;if(!oe(N,o))return;e.preventDefault(),e.stopPropagation();const s=rt(e),r=s?st(s):null;dt(s,n,r,"drop")},!0),document.addEventListener("input",dn,!0),setInterval(cn,700))}const ut=Kt();ut.isTop||!ut.isCrossOriginFrame?(un(),le(),Xe(),tn(),nn(),on(),nt(),new MutationObserver(t=>{let n=!1;for(const o of t){if(o.type==="childList"&&(o.addedNodes.length||o.removedNodes.length)){n=!0;break}if(o.type==="attributes"){n=!0;break}}n&&(Ke(),xe())}).observe(document.documentElement,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["type","style","class","hidden","disabled","readonly"]}),window.addEventListener("scroll",xe,{passive:!0,capture:!0}),window.addEventListener("resize",xe,{passive:!0}),window.addEventListener("focus",()=>{le(),Xe()}),document.addEventListener("visibilitychange",()=>{document.hidden||le()}),window.addEventListener("pagehide",()=>{O(),K()})):console.debug("[XoraPass] Autofill disabled inside third-party iframe.")})();
